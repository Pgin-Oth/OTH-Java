CREATE VIEW VAUFTRAG AS SELECT AuftrNr, Datum, Kunde.Name, Personal.Name, SUM(Gesamtpreis)
FROM Auftrag 
JOIN Kunde ON Kunde.Nr = Auftrag.Kundnr 
JOIN Personal USING (Persnr)
JOIN Auftragsposten USING (Auftrnr)
GROUP BY Auftrnr, Datum, Kunde.Name, Personal.Name
/
