CREATE VIEW VFACT1 AS Select ArtId, CustId, OrdId, OrderDate As SalesDate, 
       To_Char(OrderDate, 'MM') As Month,
       To_Char(OrderDate, 'YYYY') As Year,
       Round(Totalprice/Quantity, 2) As Price,
       Quantity
From   Orders Natural Inner Join Orderposition
/
