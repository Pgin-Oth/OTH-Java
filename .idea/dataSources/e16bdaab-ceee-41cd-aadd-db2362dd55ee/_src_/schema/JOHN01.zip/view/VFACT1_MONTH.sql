CREATE VIEW VFACT1_MONTH AS Select ArtId, Month, Year, Round(AVG(Price), 2), Sum(Quantity)
From VFact1
GROUP BY ArtId, Month, Year
/
